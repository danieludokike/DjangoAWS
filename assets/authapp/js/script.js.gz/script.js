/***********************************************************
 *
 * Project name: 	Nimoy · Login & Register Form HTML Template
 * Decription: 		HTML | Miscellaneous Template for ThemeForest.net
 * Author: 			ceosDesigns
 * Link:			http://nimoy.ceosdesigns.sk/ 
 * Version:			1.00
 *
 ************************************************************/

(function ($) {
	"use strict";

    $(window).on('load', function () {
        // remove preloader
        $('.nm-ripple').fadeOut(500, function () {
            $('#nm-preloader').fadeOut(500);
        });
    });
})(jQuery)